package Boundary;

import Control.Hashingtable;
import Control.PasswordMgr;
import Entity.Password;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class PasswordUI {
    public static void main(String args[]) throws NoSuchAlgorithmException, IOException {
        PasswordMgr.addPassword(new Password("C190195", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword1"))));
        PasswordMgr.addPassword(new Password("TEJAS005", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword2"))));
        PasswordMgr.addPassword(new Password("DODDI003", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword3"))));
        PasswordMgr.addPassword(new Password("KJ004", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword4"))));
        PasswordMgr.addPassword(new Password("MERVYN007", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword5"))));
        PasswordMgr.addPassword(new Password("ZHEREN002", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword6"))));
        PasswordMgr.addPassword(new Password("ADAM2", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword7"))));
        PasswordMgr.addPassword(new Password("EVE6", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword8"))));
        PasswordMgr.addPassword(new Password("ADELE", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword9"))));
        PasswordMgr.addPassword(new Password("JOHNNY", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword10"))));
        PasswordMgr.addPassword(new Password("SALLY", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword11"))));
        PasswordMgr.addPassword(new Password("POLLY56", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword12"))));
        PasswordMgr.addPassword(new Password("PINITO", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword13"))));
        PasswordMgr.addPassword(new Password("PEWDIE", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword14"))));
        PasswordMgr.addPassword(new Password("RANDY", "student",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword15"))));
        PasswordMgr.addPassword(new Password("ADMIN1", "admin",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword16"))));
        PasswordMgr.addPassword(new Password("ADMIN2", "admin",
                Hashingtable.hexercon(Hashingtable.hasho("Testpassword17"))));
    }
}
