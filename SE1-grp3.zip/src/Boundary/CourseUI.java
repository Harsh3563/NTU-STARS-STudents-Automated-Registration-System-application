package Boundary;

import Control.CourseMgr;
import Control.FileManipMgr;
import Entity.Admin;
import Entity.Course;
import Entity.IndexGroup;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Scanner;

public class CourseUI {
    /**
     * CourseUI will allow user to add
     * Course or change AUcount or change School
     * or the max Limit for a course
     * or the Course Code
     * or the Tutorial count
     * or the Lab count
     * and print all course codes
     * @param a admin who is logged in
     * @throws ClassNotFoundException Error detection
     * @throws NoSuchMethodException Error detection
     * @throws IOException Error detection
     * @throws IllegalAccessException Error detection
     * @throws InvocationTargetException Error detection
     */
    public static void CourseApp(Admin a) throws ClassNotFoundException, NoSuchMethodException, IOException, IllegalAccessException, InvocationTargetException {

        int choice = 0;
        String courseCode, newCourseCode;
        int numAUs;
        String school;
        int maxLimit;
        /**
         * Create new manager object and scanner to receive user input
         */
        Scanner sc = new Scanner(System.in);
        int index;
        do {
            try {
                System.out.println("\nCourse Application\n"
                        + "Select your choice:\n"
                        + "[1] Add course to List\n"
                        + "[2] Change number of AUs\n"
                        + "[3] Change School\n"
                        + "[4] Change Max Limit\n"
                        + "[5] Change Course Code\n"
                        + "[6] View Vacancy in Index Group\n"
                        + "[7] Print all course codes\n"
                        + "[8] Back");
                choice = sc.nextInt();
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid choice! Please enter an integer value");
                continue;
            }
            /**
             * Depending on what the user wants to do
             * switch case will output corresponding function
             */
            switch (choice) {
                case 1:
                    /**
                     * Checks if the course code already exists
                     * and if not it will add it into the list
                     */
                    try {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        if (CourseMgr.checkIfCourseExists(courseCode) != -1) {
                            System.out.println("Course Code already exists!");
                            break;
                        } else {
                            CourseMgr.addCoursetoList(courseCode);
                            break;
                        }
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                        break;
                    }
                case 2:
                    /**
                     * Changes the AU of a selected course code,
                     * while also checking if the course code exists
                     */
                    try {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        index = CourseMgr.checkIfCourseExists(courseCode);
                        if (index == -1) {
                            System.out.println("Course does not exist!");
                            break;
                        }
                    try {
                        System.out.print("Enter new number of AUs: ");
                        numAUs = sc.nextInt();
                    }
                    catch(NumberFormatException e)
                        {
                            System.out.println("IO Error! Please try again");
                            break;
                        }
                        CourseMgr.changeAU(courseCode, numAUs, index);
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                        break;
                    }
                    break;
                case 3:
                    /**
                     * Changes the school but will check if course code is present first
                     */
                    try {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        index = CourseMgr.checkIfCourseExists(courseCode);
                        if (index == -1) {
                            System.out.println("Course does not exist!");
                            break;
                        }
                        try {
                            System.out.print("Enter new school: ");
                            school = sc.next();
                        } catch (Exception e) {
                            System.out.println("IO Error! Please try again");
                            break;
                        }
                        CourseMgr.changeSchool(courseCode, school, index);
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                        break;
                    }
                    break;
                case 4:
                    /**
                     * Check if course code is available
                     * then changes the max limit of students
                     * for the course chosen
                     */
                    try
                    {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        index = CourseMgr.checkIfCourseExists(courseCode);
                        if(index == -1) {
                            System.out.println("Course does not exist!");
                            break;
                        }
                        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
                        Course c = (Course) courseList.get(index);
                        IndexGroup[] indexGroups = c.getIndexList();
                        int counter = 0;
                        for(IndexGroup ig: indexGroups){
                            System.out.println(counter + ". " + ig.getIndexNumber());
                        }
                        int choice1 = sc.nextInt();
                        IndexGroup i = indexGroups[choice1 - 1];
                        try
                        {
                            System.out.print("Enter new max number of students: ");
                            maxLimit = sc.nextInt();
                        }
                        catch (NumberFormatException e)
                        {
                            System.out.println("IO Error! Please try again");
                            break;
                        }
                        CourseMgr.changeMaxLimit(courseCode, maxLimit, index, i.getIndexNumber());
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                        break;
                    }
                    break;
                case 5:
                    /**
                     * Check if the course exists
                     * then changes the course code
                     */
                    try
                    {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        index = CourseMgr.checkIfCourseExists(courseCode);
                        if(index == -1) {
                            System.out.println("Course does not exist!");
                            break;
                        }
                        try
                        {
                            System.out.print("Enter new course code: ");
                            newCourseCode = sc.next();
                        }
                        catch (Exception e)
                        {
                            System.out.println("IO Error! Please try again");
                            break;
                        }
                        CourseMgr.changeCourseCode(courseCode, newCourseCode, index);
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                        break;
                    }
                    break;
                case 6:
                    /** Check if the course exists in the first place
                     * Change the Index
                     *
                     */
                    try {
                        System.out.print("Enter desired course code: ");
                        courseCode = sc.next();
                        try {
                            index = CourseMgr.checkIfCourseExists(courseCode);
                            if (index == -1) {
                                System.out.println("Course does not exist!");
                                break;
                            }
                        } catch (Exception e) {
                            System.out.println("IO error! Please try again");
                            break;
                        }
                        CourseMgr.viewVacancyInIndex(courseCode, index);
                    }
                    catch (Exception e)
                    {
                        System.out.println("IO Error! Please try again");
                    }
                    break;

                case 7:
                    /**
                     * Prints out all the courses
                     */
                    CourseMgr.printCourses();
                    break;
                case 8: return;
                /*case 100:
                    CourseMgr.printEveryCourseDetailPossible();
                    break;*/
                default:
                    System.out.println("Thank you for using STARS!!!\n"
                            + "Have a good day!");
            }
        } while (choice != -1);
    }
}
