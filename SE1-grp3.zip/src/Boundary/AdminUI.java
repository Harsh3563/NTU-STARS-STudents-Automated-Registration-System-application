package Boundary;

import Entity.Admin;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class AdminUI {
    /**
     *
     * @param a admin who is logged in
     * @throws ClassNotFoundException Error detection
     * @throws NoSuchMethodException Error detection
     * @throws InvocationTargetException Error detection
     * @throws IOException Error detection
     * @throws IllegalAccessException Error detection
     */
    public static void AdminApp(Admin a) throws ClassNotFoundException, NoSuchMethodException,
            InvocationTargetException, IOException, IllegalAccessException {
        int choice = 0;
        do {
            System.out.println("Hi " + a.getName());
            System.out.println("Choose your option according to the following menu:");
            System.out.println("1. Check/Add/Update Student records.");
            System.out.println("2. Check/Add/Update Course records.");
            System.out.println("3. Print student list.");
            System.out.println("4. Back.");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    StudentUI.StudentApp(a);
                    break;
                case 2:
                    CourseUI.CourseApp(a);
                    break;
                case 3:
                    StudentListUI.StudentListApp(a);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Please enter a correct option.");
            }
        }while(choice!=4);
    }
}
