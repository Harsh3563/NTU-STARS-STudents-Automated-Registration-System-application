package Boundary;

import Control.StudentListMgr;
import Entity.Admin;

import java.util.Scanner;

public class StudentListUI {
    /**
     *
     * @param a admin who is logged in
     */
    public static void StudentListApp(Admin a){
        /**
         * Student list function
         * Depending on user choice it will either print the list by course
         * or print student list by index group
         */
        Scanner sc = new Scanner(System.in);
        int choice;
        String courseCode;
        System.out.println("Hi " + a.getName());
        do{
            System.out.println("Choose your option according to the following menu: ");
            System.out.println("1. Print student list by course.\n" +
                    "2. Print student list by index group.\n3. Back");
            choice =  sc.nextInt();
            switch(choice){
                case 1:
                    try {
                        System.out.println("Enter the course code.");
                        courseCode = sc.next();
                    }
                    catch (Exception e){
                        System.out.println("Input error!");
                        break;
                    }
                    StudentListMgr.printStudentListByCourse(courseCode);
                    break;
                case 2:
                    try {
                        System.out.println("Enter the course code.");
                        courseCode = sc.next();
                    }
                    catch (Exception e){
                        System.out.println("Input error!");
                        break;
                    }
                    StudentListMgr.printStudentListByIndexGroup(courseCode);
                    break;
                case 3: return;
                default: System.out.println("Please enter a valid option.");
            }
        }while(choice!=-1);

    }
}
