package Boundary;

import Control.AdminMgr;
import Entity.Admin;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class AddAdminRecords {
    public static void main(String args[]) throws ClassNotFoundException, NoSuchMethodException,
            InvocationTargetException, IllegalAccessException, IOException {
        AdminMgr.addAdmin(new Admin("ADMIN1", "Sidd", "test@gmail.com"));
        AdminMgr.addAdmin(new Admin("ADMIN2", "KJ", "test1@gmail.com"));
        //List<Object> adminList = FileManipMgr.readObjectsFromFile("admin.dat");
        //for(Object a: adminList)
            //System.out.println(((Admin)a).getName());
    }
}
