package Boundary;

import Control.PasswordMgr;
import Entity.Admin;
import Control.Hashingtable;
import Entity.Password;
import Entity.Student;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class LoginUI {
    /**
     * UI for users when they enter the system
     * User login UI
     * @param args necessary java syntax
     * @throws NoSuchAlgorithmException thrown when hashing error occurs
     */
    public static void main(String args[]) throws NoSuchAlgorithmException, IOException,
            ClassNotFoundException, NoSuchMethodException, IllegalAccessException,
            InvocationTargetException {
        Scanner scd = new Scanner(System.in);
        while(true) {
            System.out.println("Press q to quit.");
            String Name, Domain, Password1, enPassword;
            System.out.println("Please enter Username: ");
            Name = scd.next();
            if(Name.equals("q"))
                System.exit(0);
            System.out.println("Please enter Domain (student/admin): ");
            Domain = scd.next();
            if(Domain.equals("q"))
                System.exit(0);
            else if(!Domain.equals("student") && !Domain.equals("admin")) {
                System.out.println("Please enter a correct domain (student/admin).");
                continue;
            }
            System.out.println("Please enter the password");
            Password1 = scd.next();
            if(Password1.equals("q"))
                System.exit(0);
            enPassword = Hashingtable.hexercon(Hashingtable.hasho(Password1));
            Password login = new Password(Name, Domain, enPassword);
            int verified = PasswordMgr.validatePassword(login);
            if (verified == -1) {
                System.out.println("Login failed!");
                continue;
            }
            if(Domain.equals("student")){
                Student s = PasswordMgr.retrieveStudentRecord(login);
                assert s != null;
                if(s.getStartDate().compareTo(LocalDate.now())>0||LocalDate.now().
                        compareTo(s.getEndDate())>0||s.getStartTime().compareTo(LocalTime.now())>0
                        ||LocalTime.now().compareTo(s.getEndTime())>0)
                {
                    System.out.println("Your access period hasn't started yet. " +
                            "Note that registration access period is from " + s.getStartDate() +
                            " to " + s.getEndDate() + " " + s.getStartTime() + "-" + s.getEndTime());
                    continue;
                }
                System.out.println("Successful login!");
                StudentRegistrationUI.StudentRegistrationApp(s);
            }
            else{
                Admin a = PasswordMgr.retrieveAdminRecord(login);
                System.out.println("Successful login!");
                AdminUI.AdminApp(a);
            }
        }
    }
}
