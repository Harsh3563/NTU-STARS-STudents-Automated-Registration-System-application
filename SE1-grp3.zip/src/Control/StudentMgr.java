package Control;

import Entity.Student;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class StudentMgr {
    /**
     * Student mgr are all functions pertaining to the student app,
     * adds student, once student object is entered to the list
     * and also checks if it already exists.
     * Method to add an object record to a file
     * and will also print if it is successful
     * @param s Student to be added
     * @return boolean Value is return to show record has been added to the file
     */
    public static boolean addStudent(Student s){
        int index = FileManipMgr.checkIfObjectExists(s);
        if(index != -1){
            System.out.println("Student record already exists. Make sure to enter the correct " +
                    "matriculation number.");
            return false;
        }
        try {
            FileManipMgr.addObjectToFile(s);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Print out all student records in the predefined file
     * @return boolean value depending of execution
     */
    public static boolean displayAllStudentRecords(){
        List<Student> studentList= new ArrayList<>();
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        for(Object o: objectList){
            studentList.add((Student)o);
        }
        if(studentList.isEmpty()){
            System.out.println("There are no student records.");
            return false;
        }
        System.out.println("*****************************************");
        System.out.printf("%-15s %-7s %-15s\n", "Name", "Gender", "Nationality");
        System.out.println("*****************************************");
        for(Student s: studentList){
            //System.out.println(s);
            s.displayDetails();
        }
        return true;
    }

    /**
     * Method to edit the student access period
     * only possible from reading the and writing student file
     * and creating a list and writing the changes into it
     * and returning the list into the file
     * @param index Variable to change predfined class attribute
     * @param startDate Variable to change predfined class attribute
     * @param endDate Variable to change predfined class attribute
     * @param startTime Variable to change predfined class attribute
     * @param endTime Variable to change predfined class attribute
     * @return boolean Value to show that read and writing process is successful
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean editStudentAccessPeriod(int index, LocalDate startDate, LocalDate endDate,
       LocalTime startTime, LocalTime endTime) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setStartDate(startDate);
        s1.setEndDate(endDate);
        s1.setStartTime(startTime);
        s1.setEndTime(endTime);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /*public static boolean displayEveryPossibleStudentDetail() {
        List<Student> studentList= new ArrayList<>();
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        for(Object o: objectList){
            studentList.add((Student)o);
        }
        if(studentList.isEmpty()){
            System.out.println("There are no student records.");
            return false;
        }
        for(Student s: studentList){
            //System.out.println(s);
            s.displayEveryDetail();
        }
        return true;
    }*/

    /**
     * Checks if student exists
     * @param s Student object to check if it exists
     * @return Int value is returned to show if the object exists
     */
    public static int checkIfStudentExists(Student s){
        return(FileManipMgr.checkIfObjectExists(s));
    }

    /**
     *
     * @param studentList list of students to be written to the file
     * @return boolean value to indicate successful execution
     */
    public static boolean writeStudentsToFile(List<Object> studentList){
        try {
            FileManipMgr.writeObjectsToFile(studentList, "student.dat");
        } catch (IOException e) {
            //e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Change name and store changes into the
     * list writes it into the pre defined file
     * @param name New name of person to be updated
     * @param index Location of the name
     * @return boolean Value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeName(String name, int index) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setName(name);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * Changes username and store changes into the
     *  list writes it into the pre defined file
     * @param networkUsername to be changed to
     * @param index Index to change to
     * @return boolean Value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeNetworkUsername(String networkUsername, int index)throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        String oldNetworkUsername = s1.getNetworkUsername();
        s1.setNetworkUsername(networkUsername);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        PasswordMgr.reflectChangesInNetworkUsername(oldNetworkUsername, networkUsername);
        return true;
    }

    /**
     * Changes matric number and store changes into the
     * list writes it into the pre defined file
     * @param oldMatricNumber old matric number
     * @param newMatricNumber new matric number
     * @param index Index to locate the matric number
     * @return boolean value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeMatricNumber(String oldMatricNumber, String newMatricNumber, int index)
            throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setMatricNumber(newMatricNumber);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        HashMap<String, Integer> courses = s1.getCourses();
        Iterator<Map.Entry<String, Integer>> it = courses.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Integer> l = it.next();
            String courseCode = l.getKey();
            int indexNum = l.getValue();
            CourseMgr.reflectChangeInStudentMatricNum(courseCode, indexNum, oldMatricNumber, newMatricNumber);
        }
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * Changes EmailID and store changes into the
     * list writes it into the pre defined file
     * @param emailID EmailID to be changed to
     * @param index Index to locate the Email
     * @return boolean Value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeEmailID(String emailID, int index)throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setEmailID(emailID);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * Changes Nationality and store changes into the
     * list writes it into the pre defined file
     * @param nationality New nationality to change to
     * @param index Index to find the location to change
     * @return boolean Value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeNationality(String nationality, int index)throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setNationality(nationality);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * Changes gender and store changes into the
     * list writes it into the pre defined file
     * @param gender Gender variable to be swapped to
     * @param index Index to locate the value
     * @return boolean Value is returned to show outcome of the process
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeGender(char gender, int index)throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s1 = (Student)objectList.get(index);
        s1.setGender(gender);
        objectList.set(index, s1);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * To store all changes and update the predefined file
     * @param matricNum matric number of student
     * @param oldCourseCode old course code
     * @param newCourseCode new course code
     * @return boolean Value to show that the process is successful
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean reflectChangesInCourseCode(String matricNum, String oldCourseCode,
                                                     String newCourseCode) throws IOException {
        int index_student = FileManipMgr.checkIfObjectExists(new Student(matricNum));
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s = (Student) objectList.get(index_student);
        s.reflectChangesInCourseCode(oldCourseCode, newCourseCode);
        objectList.set(index_student, s);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * To store all changes and update the predefined file for the AU count
     * @param matricNum matric number of student
     * @param oldAU old number of AUs
     * @param newAU new number of AUs
     * @return boolean Value to show that the process is successful
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean reflectChangesInAU(String matricNum, int oldAU, int newAU)
            throws IOException {
        int index_student = FileManipMgr.checkIfObjectExists(new Student(matricNum));
        List<Object> objectList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s = (Student) objectList.get(index_student);
        s.reflectChangesInAU(oldAU, newAU);
        objectList.set(index_student, s);
        FileManipMgr.writeObjectsToFile(objectList, "student.dat");
        return true;
    }

    /**
     * To store all changes and update the predefined file for the maxlimit
     * @param s matric number of student
     * @param courseCode course code
     * @param AUs AU credits of course
     * @param indexNum index number for which max limit was changed
     * @return boolean Value to show that the process is successful
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean reflectChangesInMaxLimit(String s, String courseCode, int AUs, int indexNum)
            throws IOException {
        Student s1 = new Student(s);
        int newStudentIndex = FileManipMgr.checkIfObjectExists(s1);
        List<Object> studentList = FileManipMgr.readObjectsFromFile("student.dat");
        s1 = (Student) studentList.get(newStudentIndex);
        s1.changeWaitingToRegistered(courseCode, AUs);
        studentList.set(newStudentIndex, s1);
        NotificationMgr.sendEmail(s1.getEmailID(), courseCode, indexNum);
        FileManipMgr.writeObjectsToFile(studentList, "student.dat");
        return true;
    }
}
