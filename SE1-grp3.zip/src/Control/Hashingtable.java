package Control;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hashingtable {
    /**
     * Create an original byte to hexadecimcal converter
     * this is to create an byte array
     * @param inputed string to be converted
     * @return byte array
     * @throws NoSuchAlgorithmException
     */
    public static byte[] hasho(String inputed) throws NoSuchAlgorithmException {
        MessageDigest msg=MessageDigest.getInstance("SHA-256");
        /**
         * digest() is hash function <- the hash formula is inside
         * this is the hasher to see changes and alterations
         */
        return msg.digest(inputed.getBytes(StandardCharsets.UTF_8));
    }
    /**
     * String to hexadecimal conversion
     * @param sha byte array is feeded here
     * @return converted encrymption is returned
     */
    public static String hexercon(byte[] sha) {
        /**
         * Array will then be converted using signum and depending on the value
         * convert the original msg to hash
         * and then pad the zeros
         */
        BigInteger num= new BigInteger(1,sha);
        StringBuilder hexor=new StringBuilder(num.toString(16));
        while(hexor.length()<32) {
            hexor.insert(0,'0');
        }
        return hexor.toString();
    }

}
