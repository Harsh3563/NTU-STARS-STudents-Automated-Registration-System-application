package Control;

import Entity.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class StudentRegistrationMgr {

    /**
     * Checks if user exists then
     * checks if course exists, read objects from predefined files
     * then add the student for the course
     * but will also check for vacancies
     * and place user onto the waitiing list
     * depending on course avaialability
     * @param student Student user to be registered
     * @param courseCode For student to be registered
     * @param indexNum The course index value
     * @return boolean Value is returned to show outcome of the process
     */
    public static boolean registerStudentForCourse(Student student, String courseCode, int indexNum) {
        //int index_student = findStudentByMatricNum(username);
        int index_student = StudentMgr.checkIfStudentExists(student);
        if (index_student == -1) {
            System.out.println("Did not find student record with this username.");
            return false;
        }
        int index_course = CourseMgr.checkIfCourseExists(courseCode);
        if (index_course == -1) {
            System.out.println("Did not find course record with this course code.");
            return false;
        }
        List<Object> studentList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s = (Student) (studentList.get(index_student));
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        Course c = (Course) (courseList.get(index_course));
        if (s.checkIfAlreadyApplied(c.getCourseCode()))
            return false;
        IndexGroup i = null;
        IndexGroup[] indexList = c.getIndexList();
        int count = 0, index_ig = 0;
        for (IndexGroup ig : indexList) {
            if (ig.getIndexNumber() == indexNum) {
                i = ig;
                index_ig = count;
                break;
            }
            count++;
        }
        boolean toAddToWaitingList = false;
        List<Lesson> lessonList = new ArrayList<>(Arrays.asList(i.getLessons()));
        lessonList.addAll(Arrays.asList(c.getLectureLessons()));
        Lesson[] lessons = new Lesson[lessonList.size()];
        int counter = 0;
        for (Lesson l : lessonList) {
            lessons[counter] = l;
            counter++;
        }
        TimeTable timeTable = s.getTimeTable();
        if (!timeTable.checkForClash(lessons, courseCode))
            return false;
        if ((s.getAUsRegistered() + c.getAUs()) > 6) {
            System.out.println("Cannot register for this course as it will exceed the maximum AU (6) " +
                    "limit Consider dropping some course. You will not be placed on waitlist");
            return false;
        }
        if (c.getVacancy() == 0) {
            System.out.println("Note that there in no vacancy for this course. You will be placed on " +
                    "waitlist");
            toAddToWaitingList = true;
        } else if (i.getVacancy() == 0) {
            System.out.println("Note that there is no vacancy for this index group. You will be placed " +
                    "on waitlist.");
            toAddToWaitingList = true;
        }
        System.out.println(toAddToWaitingList);
        if (toAddToWaitingList) {
            s.addCourseToWaitingList(courseCode, indexNum);
            s.getTimeTable().addLesson(courseCode, indexNum, lessons, "WAITING");
            i.addStudentToWaitingList(s.getMatricNumber());
            indexList[index_ig] = i;
            c.setIndex(indexList);
        } else {
            s.registerForCourse(courseCode, indexNum, c.getAUs());
            s.getTimeTable().addLesson(courseCode, indexNum, lessons, "REGISTERED");
            i.addStudent(s.getMatricNumber());
            indexList[index_ig] = i;
            c.setIndex(indexList);
            c.addStudent(s.getMatricNumber());
        }
        studentList.set(index_student, s);
        courseList.set(index_course, c);
        StudentMgr.writeStudentsToFile(studentList);
        CourseMgr.writeCoursesToFile(courseList);
        return true;
    }

    /**
     * Needs to remove the course
     * by checking of student record exists and
     * finding the course record for it
     * @param student Student object to be deregistered
     * @param courseCode Course code of the deregistered student
     * @return boolean Balue is returned to show outcome of the process
     */
    public static boolean deregisterStudentFromCourse(Student student, String courseCode) {
        int index_student = StudentMgr.checkIfStudentExists(student);
        if (index_student == -1) {
            System.out.println("Did not find student record with this username.");
            return false;
        }
        int index_course = CourseMgr.checkIfCourseExists(courseCode);
        if (index_course == -1) {
            System.out.println("Did not find course record with this course code.");
            return false;
        }
        List<Object> studentList = FileManipMgr.readObjectsFromFile("student.dat");
        Student s = (Student) (studentList.get(index_student));
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        Course c = (Course) (courseList.get(index_course));
        Integer[] result = s.deregisterFromCourse(c.getCourseCode(), c.getAUs());
        int status = result[0];
        int indexNum = result[1];
        IndexGroup i = null;
        IndexGroup[] indexList = c.getIndexList();
        int count = 0, index_ig = 0;
        for (IndexGroup ig : indexList) {
            if (ig.getIndexNumber() == indexNum) {
                i = ig;
                index_ig = count;
                break;
            }
            count++;
        }
        String matricNumOfNewStud = i.removeStudent(s.getMatricNumber(), status);
        if (!matricNumOfNewStud.equals("NoWaiting")) {
            Student s1 = new Student(matricNumOfNewStud);
            int newStudentIndex = FileManipMgr.checkIfObjectExists(s1);
            s1 = (Student) studentList.get(newStudentIndex);
            s1.changeWaitingToRegistered(c.getCourseCode(), c.getAUs());
            c.addStudent(matricNumOfNewStud);
            studentList.set(newStudentIndex, s1);
            //System.out.println(s1.getEmailID());
            NotificationMgr.sendEmail(s1.getEmailID(), courseCode, indexNum);
        }
        indexList[index_ig] = i;
        c.setIndex(indexList);
        System.out.println(status);
        if (status == 1)
            c.removeStudent(s.getMatricNumber());
        studentList.set(index_student, s);
        courseList.set(index_course, c);
        StudentMgr.writeStudentsToFile(studentList);
        CourseMgr.writeCoursesToFile(courseList);
        return true;
    }

    /**
     * Checks if the student has any courses
     * then prints out the total amount registered
     * @param student student who is logged in
     */
    public static boolean printCoursesRegistered(Student student) {
        if(student.getCourses().isEmpty()) {
            System.out.println("You have neither registered nor are on waiting list for any courses!");
            return false;
        }
        student.getTimeTable().printTimeTable();
        System.out.println("Total AUs Registered: " + student.getAUsRegistered());
        return true;
    }

    /**
     * Finds if course is present from predefined file then
     * changes the index group of the course
     * @param student User that required to change index
     * @param courseCode Is the course that we want to change the index of
     * @param newIndexNum New index value to change into
     * @return boolean Value is returned to show outcome of the process
     */
    public static boolean changeIndexGroup(Student student, String courseCode,
                                           int newIndexNum) {
        int index_course = CourseMgr.checkIfCourseExists(courseCode);
        if (index_course == -1) {
            System.out.println("Did not find course record with this course code.");
            return false;
        }
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        Course c = (Course) (courseList.get(index_course));
        IndexGroup i = null;
        IndexGroup[] indexList = c.getIndexList();
        for (IndexGroup ig : indexList) {
            if (ig.getIndexNumber() == newIndexNum) {
                i = ig;
                break;
            }
        }
        List<Lesson> lessonList = new ArrayList<>(Arrays.asList(i.getLessons()));
        lessonList.addAll(Arrays.asList(c.getLectureLessons()));
        Lesson[] lessons = new Lesson[lessonList.size()];
        int counter = 0;
        for (Lesson l : lessonList) {
            lessons[counter] = l;
            counter++;
        }
        if (!student.getTimeTable().checkForClash(lessons, courseCode)) {
            return false;
        }
        deregisterStudentFromCourse(student, courseCode);
        //System.out.println("Hey");
        registerStudentForCourse(student, courseCode, newIndexNum);
        return true;
    }

    /**
     * Swapping with 2 users,
     * first checks both student records and also the
     * course codes and also check if both are
     * registered for the course
     * also checks if both are already in the same group
     * and then finally changes all the neccesasry details
     * with changing an index by calling all the relevant functions
     * @param student Object to be checked with the records
     * @param peer Person to swap index with
     * @param courseCode Course code for the index swap
     * @return boolean value is returned to show the outcome of the process
     */
    public static boolean swapIndexGroupWithPeer(Student student, Student peer, String courseCode) {

        int index_student = StudentMgr.checkIfStudentExists(student);
        if (index_student == -1) {
            System.out.println("Did not find student record with this username.");
            return false;
        }
        int index_peer = StudentMgr.checkIfStudentExists(peer);
        if (index_peer == -1) {
            System.out.println("Did not find student record with this username.");
            return false;
        }
        int index_course = CourseMgr.checkIfCourseExists(courseCode);
        if (index_course == -1) {
            System.out.println("Did not find course record with this course code.");
            return false;
        }
        List<Object> studentList = FileManipMgr.readObjectsFromFile("student.dat");
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        Course c = (Course) (courseList.get(index_course));
        if(!peer.getCoursesRegistered().containsKey(courseCode)){
            System.out.println("The second student is not registered for this course!");
            return false;
        }
        int indexNum1 = student.getCoursesRegistered().get(courseCode);
        int indexNum2 = peer.getCourses().get(courseCode);
        if(indexNum1 == indexNum2){
            System.out.println("You are both already in the same index group!");
            return false;
        }
        IndexGroup i1 = null, i2 = null;
        IndexGroup[] indexList = c.getIndexList();
        for (IndexGroup ig : indexList) {
            if (ig.getIndexNumber() == indexNum1) {
                i1 = ig;
            }
            if(ig.getIndexNumber() == indexNum2){
                i2 = ig;
            }
            if(i1 != null && i2 != null)
                break;
        }
        List<Lesson> lessonList = new ArrayList<>(Arrays.asList(i2.getLessons()));
        lessonList.addAll(Arrays.asList(c.getLectureLessons()));
        Lesson[] lessons1 = new Lesson[lessonList.size()];
        int counter = 0;
        for (Lesson l : lessonList) {
            lessons1[counter] = l;
            counter++;
        }
        if (!student.getTimeTable().checkForClash(lessons1, courseCode)) {
            return false;
        }
        lessonList = new ArrayList<>(Arrays.asList(i1.getLessons()));
        lessonList.addAll(Arrays.asList(c.getLectureLessons()));
        Lesson[] lessons2 = new Lesson[lessonList.size()];
        counter = 0;
        for(Lesson l: lessonList){
            lessons2[counter] = l;
            counter++;
        }
        if (!peer.getTimeTable().checkForClash(lessons2, courseCode)) {
            return false;
        }
        c.swapStudents(student, peer, indexNum1, indexNum2);
        student.changeIndex(courseCode, indexNum2, lessons1);
        peer.changeIndex(courseCode, indexNum1, lessons2);
        studentList.set(index_student, student);
        studentList.set(index_peer, peer);
        courseList.set(index_course, c);
        StudentMgr.writeStudentsToFile(studentList);
        CourseMgr.writeCoursesToFile(courseList);
        return true;
    }

    /**
     * function for a student to view vacancies in a specific index group
     * @return boolean value is returned to show the outcome of the process
     */
    public static boolean viewVacancies(){
        List<Course> courseList = CourseMgr.obtainCourseList();
        System.out.println("Choose among the following courses (by inputting the respective " +
                "choice number.");
        System.out.println("========================================");
        System.out.printf("%-10s %-15s %-7s\n", "Course Title", "Course Code", "No. of AUs");
        System.out.println("========================================");
        int counter = 0;
        for(Course c: courseList){
            System.out.printf((counter + 1) + ". %-10s %-15s %-7s\n", c.getCourseTitle(),
                    c.getCourseCode(), c.getAUs());
            counter++;
        }
        Scanner sc = new Scanner(System.in);
        int choice1 = sc.nextInt();
        Course course = courseList.get(choice1 - 1);
        IndexGroup[] indexList = course.getIndexList();
        counter = 0;
        System.out.println("============================");
        System.out.printf("%-11s %-7s %-7s\n", "Index Group", "Vacancy", "Waiting");
        System.out.println("============================");
        for(IndexGroup ig: indexList){
            System.out.print((counter + 1) + ". ");
            ig.printIndexDetails();
            counter++;
        }
        return true;
    }
}

