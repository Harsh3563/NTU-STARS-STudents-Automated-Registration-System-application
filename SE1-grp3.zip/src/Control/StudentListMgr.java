package Control;

import Entity.Course;
import Entity.IndexGroup;
import Entity.Student;

import java.util.List;
import java.util.Scanner;

public class StudentListMgr {
    /**
     * Function will print all the courses stored in the student data file
     * @param courseCode course code of course for which students registered are to be printed
     * @return boolean that shows the functions has successfully executed
     */
    public static boolean printStudentListByCourse(String courseCode){
        Course c = new Course(courseCode);
        int index_course = FileManipMgr.checkIfObjectExists(c);
        if(index_course == -1){
            System.out.println("Course code does not exist!");
            return false;
        }
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        c = (Course) courseList.get(index_course);
        List<Object> studList = FileManipMgr.readObjectsFromFile("student.dat");
        String[] registeredStudents = c.getRoster();
        int numStudentsRegistered = c.getNumStudentRegistered();
        if(numStudentsRegistered == 0) {
            System.out.println("No students registered!");
            return true;
        }
        for(int i=0; i<numStudentsRegistered; ++i){
            //System.out.println(i);
            Student s = new Student(registeredStudents[i]);
            int index_student = FileManipMgr.checkIfObjectExists(s);
            s = (Student) studList.get(index_student);
            s.displayDetails();
        }
        return true;
    }

    /**
     * Printing method
     * @param courseCode course code of course for which to choose index group to print students
     * @return boolean that shows the functions has successfully executed
     */
    public static boolean printStudentListByIndexGroup(String courseCode){
        List<Object> studList = FileManipMgr.readObjectsFromFile("student.dat");
        Course c = new Course(courseCode);
        int index_course = FileManipMgr.checkIfObjectExists(c);
        if(index_course == -1){
            System.out.println("Course code does not exist!");
            return false;
        }
        List<Course> courseList = CourseMgr.obtainCourseList();
        c = courseList.get(index_course);
        int counter = 1;
        System.out.println("Choose from the following index groups:");
        IndexGroup[] indexGroups = c.getIndexList();
        for(IndexGroup i: indexGroups){
            System.out.println(counter + ". " + i.getIndexNumber());
            counter++;
        }
        Scanner sc = new Scanner(System.in);
        int choice1 = sc.nextInt();
        IndexGroup ig = indexGroups[choice1 - 1];
        String[] registeredStudents = ig.getStudentList();
        int numStudentsRegistered = ig.getNumStudentsRegistered();
        if(numStudentsRegistered == 0)
            System.out.println("No students registered!");
        for(int i=0; i<numStudentsRegistered; ++i) {
            Student s = new Student(registeredStudents[i]);
            int index_student = FileManipMgr.checkIfObjectExists(s);
            s = (Student) studList.get(index_student);
            s.displayDetails();
        }
        return true;
    }
}
