package Control;

import Entity.Course;
import Entity.IndexGroup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseMgr {
    /**
     * Course mgr set of functions
     * that pertains to functions used in course app
     */
    static List<Course> courseList = new ArrayList<>();

    /**
     * To insert all changes
     * @param courseCode Changed coursecode to update
     * @param indexNum Changed index number
     * @param oldMatricNumber old matric number of student
     * @param newMatricNumber new matric number of student
     * @throws IOException thrown in case of file handling error
     */
    public static void reflectChangeInStudentMatricNum(String courseCode, int indexNum,
                            String oldMatricNumber, String newMatricNumber) throws IOException {
        int index_course = checkIfCourseExists(courseCode);
        List<Object> courseList = FileManipMgr.readObjectsFromFile("course.dat");
        Course c = (Course) courseList.get(index_course);
        String[] roster = c.getRoster();
        int counter = 0;
        for(String stud: roster){
            if(stud.equals(oldMatricNumber)) {
                roster[counter] = newMatricNumber;
                break;
            }
            counter++;
        }
        c.setRoster(roster);
        IndexGroup[] indexGroups = c.getIndexList();
        IndexGroup i = null;
        int index_ig = -1;
        counter = 0;
        for(IndexGroup ig: indexGroups){
            if(ig.getIndexNumber() == indexNum)
            {
                i = ig;
                index_ig = counter;
                break;
            }
            counter++;
        }
        assert i != null;
        i.reflectChangeInMatricNum(oldMatricNumber, newMatricNumber);
        indexGroups[index_ig] = i;
        c.setIndex(indexGroups);
        FileManipMgr.writeObjectsToFile(courseList, "course.dat");
    }

    /**
     * Checker to see if course object exists
     * @param courseCode course code to check if exists
     * @return int value is returned if it is exists
     */
    public static int checkIfCourseExists(String courseCode) {
        Course course = new Course(courseCode);
        return FileManipMgr.checkIfObjectExists(course);
    }

    /**
     * Adds course code into the list but more information is required,
     * still need to enter all the details
     * @param courseCode of a specific course
     */
    public static void addCoursetoList(String courseCode) {

        Scanner sc = new Scanner(System.in);
        sc.nextLine();
        System.out.println("Enter the course title: ");
        String courseTitle = sc.nextLine();
        System.out.print("Enter number of AUs: ");
        int numAUs = sc.nextInt();
        System.out.print("Enter school: ");
        String school = sc.next();

        System.out.print("Enter total number of students allowed: ");
        int maxLimit = sc.nextInt();

        System.out.print("Enter the number of tutorials: ");
        int numTuts = sc.nextInt();
        System.out.print("Enter the number of labs: ");
        int numLabs = sc.nextInt();
        System.out.print("Enter the number of lectures: ");
        int numLecs = sc.nextInt();

        Course newcourse = new Course(courseCode, courseTitle,
                numAUs, school, maxLimit, numTuts, numLabs, numLecs);//ask for lecture timings
        courseList.add(newcourse);
        try {
            FileManipMgr.addObjectToFile(newcourse);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Change AU will return a boolean expression
     * by reading the data from a pre defined file and from there change the data inside
     * set function
     * @param courseCode Change AU
     * @param newAU New AU count to change
     * @param index Indec of the Course
     * @return boolean Value to show if request is completed
     * @throws IOException thrown in case of file handling error
     */
    public static boolean changeAU(String courseCode, int newAU, int index) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        Course course = (Course) objectList.get(index);
        int oldAU = course.getAUs();
        course.setAUs(newAU);
        objectList.set(index, course);
        FileManipMgr.writeObjectsToFile(objectList, "course.dat");
        String[] studentList = course.getStudents();
        for(int i=0; i<course.getNumStudentRegistered(); ++i){
            StudentMgr.reflectChangesInAU(studentList[i], oldAU, newAU);
        }
        return true;
    }

    /**
     * function to change school of a specific course
     * @param courseCode course code of course to be modified
     * @param school new school
     * @param index index of course in course list in database
     * @return boolean Value to show if request is completed
     * @throws IOException thrown in case of file handling error
     */
    public static boolean changeSchool(String courseCode, String school, int index) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        Course course = (Course) objectList.get(index);
        course.setSchool(school);
        objectList.set(index, course);
        FileManipMgr.writeObjectsToFile(objectList, "course.dat");
        return true;
    }

    /**
     * Method to change max limit of an index group in a course
     * @param courseCode course code of course
     * @param maxLimit new max limit
     * @param index index of course in database
     * @param indexNum index number for which max limit should be changed
     * @return boolean value to indicate success of function
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean changeMaxLimit(String courseCode, int maxLimit, int index, int indexNum) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        Course course = (Course) objectList.get(index);
        IndexGroup[] indexGroups = course.getIndexList();
        IndexGroup i = null;
        int index_ig = -1, counter = 0;
        for(IndexGroup ig: indexGroups){
            if(ig.getIndexNumber() == indexNum){
                i = ig;
                index_ig = counter;
                break;
            }
            counter++;
        }
        assert i != null;
        int oldMaxLimit = i.getMaxLimit();
        if(maxLimit < oldMaxLimit){
            System.out.println("The new max. limit cannot be less than the old max. limit!");
            return false;
        }
        course.setMaxLimit(course.getMaxLimit() + maxLimit - oldMaxLimit);
        course.setVacancy(course.getVacancy() + maxLimit - oldMaxLimit);
        String[] studList = new String[course.getMaxLimit()];
        String[] oldRoster = course.getRoster();
        for (int j=0; j<course.getNumStudentRegistered(); ++j){
            studList[j] = oldRoster[j];
        }
        course.setRoster(studList);
        List<String> newStudList = i.reflectChangesInMaxLimit(oldMaxLimit, maxLimit);
        for(String s: newStudList){
            StudentMgr.reflectChangesInMaxLimit(s, courseCode, course.getAUs(), indexNum);
            course.addStudent(s);
        }
        indexGroups[index_ig] = i;
        course.setIndex(indexGroups);
        objectList.set(index, course);
        FileManipMgr.writeObjectsToFile(objectList, "course.dat");
        return true;
    }

    /**
     * Method to change the course code
     * @param courseCode The old course code to be changed
     * @param newCourseCode New course code to change to
     * @param index Index of the course
     * @return boolean Value to show if request is completed
     * @throws IOException thrown in case of file handling error
     */
    public static boolean changeCourseCode(String courseCode, String newCourseCode, int index) throws IOException {
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        Course course = (Course) objectList.get(index);
        course.setCourseCode(newCourseCode);
        objectList.set(index, course);
        FileManipMgr.writeObjectsToFile(objectList, "course.dat");
        String[] studentList = course.getRoster();
        for(int i=0; i<course.getNumStudentRegistered(); ++i){
            StudentMgr.reflectChangesInCourseCode(studentList[i], courseCode, newCourseCode);
        }
        IndexGroup[] indexGroup = course.getIndexList();
        for(IndexGroup ig: indexGroup){
            String[] studentsWaiting = ig.getStudentsWaiting();
            for(int i=0; i<ig.getNumStudentsWaiting(); ++i)
                StudentMgr.reflectChangesInCourseCode(studentsWaiting[i], courseCode, newCourseCode);
        }
        return true;
    }

    /**
     * Checks the availability of the index chosen
     * @param courseCode Course code to check
     * @param index Index of the course code
     * @return boolean Value is returned a wrong input has been scanned
     */
    public static boolean viewVacancyInIndex(String courseCode, int index){
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        Scanner sc = new Scanner(System.in);
        Course course = (Course) objectList.get(index);
        IndexGroup[] indexGroups = course.getIndexList();
        System.out.println("Choose among the following index groups:");
        int counter = 0;
        for(IndexGroup ig: indexGroups){
            System.out.println((counter + 1) + ". " + ig.getIndexNumber());
            counter++;
        }
        System.out.println((counter + 1) + ". Back");
        int choice = sc.nextInt();
        if(choice >= (counter + 1)){
            if(choice != (counter + 1))
                System.out.println("Wrong option chosen!");
            return false;
        }
        IndexGroup i = indexGroups[choice - 1];
        System.out.println("There are " + i.getVacancy() + " vacancies in this index group.");
        return true;
    }

    /**
     * Print courses will print the courses stored in the
     * predefined file which creates a list and prints it
     * @return boolean Value to show if request is completed
     */
    public static boolean printCourses() {
        courseList = new ArrayList<>();
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        for(Object o: objectList){
            courseList.add((Course) o);
        }
        if (courseList.isEmpty()){
            System.out.println("There are no course records.");
            return false;
        }
        System.out.println("******************************************************************************************************************");
        System.out.printf("%-10s %-10s %-9s %-9s %-9s %-15s %-15s %-16s\n", "Course Code", "Course Title",
                "No. of AUs", "School", "Max Limit", "No. of Tuts", "No. of Labs", "No. of Vacancies");
        System.out.println("******************************************************************************************************************");
        for (Course c: courseList){
            c.displayDetails();
        }
        return true;
    }

    /**
     * Exctraction method to get course list from a
     * predefined file
     * @return List of courses
     */
    public static List<Course> obtainCourseList(){
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        courseList = new ArrayList<>();
        for(Object o:objectList){
            courseList.add((Course)o);
        }
        return courseList;
    }

    /**
     * Method to write a course list to a file
     * @param courseList list of courses
     * @return boolean value to indicate success of function
     */
    public static boolean writeCoursesToFile(List<Object> courseList) {
        try {
            FileManipMgr.writeObjectsToFile(courseList, "course.dat");
        } catch (IOException e) {
            //e.printStackTrace();
            return false;
        }
        return true;
    }


    /*public static boolean printEveryCourseDetailPossible() {
        courseList = new ArrayList<>();
        List<Object> objectList = FileManipMgr.readObjectsFromFile("course.dat");
        for(Object o: objectList){
            courseList.add((Course) o);
        }
        if (courseList.isEmpty()){
            System.out.println("There are no course records.");
            return false;
        }
        for (Course c: courseList){
            if(c != null)
                c.displayEveryDetail();
        }
        return true;
    }*/
}
