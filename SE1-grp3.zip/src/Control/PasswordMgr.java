package Control;

import Entity.Admin;
import Entity.Password;
import Entity.Student;

import java.io.IOException;
import java.util.List;

//import java.io.FileOutputStream;
//import java.io.ObjectOutputStream;
// this is do allow user to WRITE into a precreated file, if that is not required you can just extract out the read function below and use it
//for comparison
public class PasswordMgr{
    /**
     *Passwordmgr to manage and read data from predefined password file
     *and also possible to change passwords or check if passwords is present
     */

    /**
     * Adds password to the predefine list in the file and also
     * will check of the object in the file is present
     * @param password password object to add to file
     * @throws IOException thrown if file handling error occurs
     */
    public static void addPassword (Password password) throws IOException{
        List<Object> passwordList = FileManipMgr.readObjectsFromFile("password.dat");
        passwordList.add(password);
        FileManipMgr.writeObjectsToFile(passwordList, "password.dat");
        System.out.println(FileManipMgr.checkIfObjectExists(password));
    }

    /**
     * Checks if the password exists in the
     * predefined file and will return an
     * int value
     * @param password Object to be checked against
     * @return index of password object in password database
     */
    public static int validatePassword(Password password){
        return FileManipMgr.checkIfObjectExists(password);
    }

    /**
     * Student record once password is read from the predefined file
     * and if password is correct
     * @param password Student entered password
     * @return Student Object is returned once password has been verified through equals class
     * if not it will reutrn null
     */
    public static Student retrieveStudentRecord(Password password){
        List<Object> studentList = FileManipMgr.readObjectsFromFile("student.dat");
        for(Object o: studentList){
            if(((Student)o).getNetworkUsername().equals(password.getUsername()))
                return (Student)o;
        }
        return null;
    }

    /**
     * Method will retrieve the admin record
     * from the admin predefined file
     * @param password admin pass word
     * @return admin class object is returned
     */
    public static Admin retrieveAdminRecord(Password password){
        Admin a = new Admin(password.getUsername());
        int index_admin = FileManipMgr.checkIfObjectExists(a);
        List<Object> adminList = FileManipMgr.readObjectsFromFile("admin.dat");
        a = (Admin) adminList.get(index_admin);
        return a;
    }

    /**
     * Method to also show changes in the username
     * @param oldNetworkUsername To be changed
     * @param newNetworkUsername New username to be changed with
     * @throws IOException
     */
    public static void reflectChangesInNetworkUsername(String oldNetworkUsername, String newNetworkUsername)
            throws IOException {
        List<Object> passwordList = FileManipMgr.readObjectsFromFile("password.dat");
        int counter = 0;
        Password p = null;
        for(Object o: passwordList){
            if(((Password)o).getUsername().equals(oldNetworkUsername)){
                p = (Password) o;
                p.setUsername(newNetworkUsername);
                break;
            }
            counter++;
        }
        passwordList.set(counter, p);
        FileManipMgr.writeObjectsToFile(passwordList, "password.dat");
    }
}
