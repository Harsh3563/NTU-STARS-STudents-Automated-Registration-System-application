package Control;

import Entity.Admin;
import Entity.Course;
import Entity.Password;
import Entity.Student;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManipMgr {

    /**
     * Helper method to determine correct database file based on object type
     * @param object Object input to check its type
     * @return String Specifies the location of type or will return error if a bug is found
     */
    public static String checkTypeOfObject(Object object){
        if(object instanceof Student)
            return "student.dat";
        else if (object instanceof Course)
            return "course.dat";
        else if(object instanceof Password)
            return "password.dat";
        else if(object instanceof Admin)
            return "admin.dat";
        return "Error!";
    }

    /**
     * Helper method to return an identifying number associated with instance type of an object
     * @param object Object input to check its type
     * @return int Value that will show that that the object is of that type class
     */
    public static int convertObjectToType(Object object){
        if(object instanceof Student)
            return 1;
        else if (object instanceof Course)
            return 2;
        else if(object instanceof Password)
            return 3;
        else if(object instanceof Admin)
            return 4;
        return -1;
    }

    /**
     * Method to check if an object record exists in the database
     * @param object Object input to check its type
     * @return int Value of -1 is returned when an error occurs or when file does not exist
     * and if not it will return the counter value of existing objects
     */
    public static int checkIfObjectExists(Object object){
        String file = checkTypeOfObject(object);
        //System.out.println(file);
        FileInputStream foStream = null;
        try {
            foStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            System.out.println("File does not exist");
            return -1;
            //e.printStackTrace();
        }
        BufferedInputStream boStream = new BufferedInputStream(foStream);
        ObjectInputStream oiStream = null;
        try {
            oiStream = new ObjectInputStream(boStream);
        } catch (IOException e) {
            //e.printStackTrace();
            return -1;
        }
        try{
            int counter = 0;
            while(true){
                Object inputObject;
                inputObject = oiStream.readObject();
                if(inputObject.equals(object))
                    return counter;
                counter += 1;
            }
        } catch(EOFException e){
            return -1;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Method to read all objects from a file
     * and also checks if the file is empty prior to the read process
     * @param file String location of the data to be read from
     * @return List Contains the objects stored in the file
     */
    public static List<Object> readObjectsFromFile(String file){
        FileInputStream fiStream = null;
        List<Object> objects = new ArrayList<>();
        try {
            fiStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            //e.printStackTrace();
            return objects;
        }
        BufferedInputStream biStream = new BufferedInputStream(fiStream);
        ObjectInputStream oiStream = null;
        try {
            oiStream = new ObjectInputStream(biStream);
        }catch(EOFException e){
            System.out.println("File is currently empty!");
            return objects;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try{
            while(true){
                objects.add(oiStream.readObject());
            }
        }catch (EOFException e) {
            //System.out.println("Objects successfully read!");
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return objects;
    }

    /**
     * Helper method to write a list of objects to the correct file
     * depending on the type it will write the object into that specific list
     * @param objects List of objects that will be written into the file
     * @param file Is the file that will be written to
     * @return boolean Value whether or not write operation is successful
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean writeObjectsToFile(List<Object> objects, String file) throws IOException {
        FileOutputStream foStream;
        BufferedOutputStream boStream;
        ObjectOutputStream ooStream;
        try {
            foStream = new FileOutputStream(file);
            boStream = new BufferedOutputStream(foStream);
            ooStream = new ObjectOutputStream(boStream);
        } catch (IOException e) {
            System.out.println("An IO error has occurred.");
            //e.printStackTrace();
            return false;
        }
        int requiredType = convertObjectToType(objects.get(0));
        //System.out.println(requiredType);
        for(Object o: objects){
            switch (requiredType){
                case 1: Student s = (Student) o;
                    ooStream.writeObject(s);
                    break;
                case 2: Course c = (Course) o;
                    ooStream.writeObject(c);
                    break;
                case 3: Password p = (Password) o;
                    ooStream.writeObject(p);
                    break;
                case 4: Admin a = (Admin) o;
                    ooStream.writeObject(a);
                    System.out.println(a.getNetworkUsername());
                    break;
            }
        }
        ooStream.close();
        return true;
    }

    /**
     * Method to add an object record to a file
     * and will also print if it is successful
     * @param object Object that will be written to the file
     * @return boolean Shows that the record has been added to the file
     * @throws IOException thrown when file handling error occurs
     */
    public static boolean addObjectToFile(Object object) throws IOException {
        List<Object> objects = new ArrayList<>();
        String file = checkTypeOfObject(object);
        objects = readObjectsFromFile(file);
        objects.add(object);
        /*for(Object o: objects){
            System.out.println(o);
        }*/
        writeObjectsToFile(objects, file);
        System.out.println("Records successfully added!");
        return true;
    }
}
