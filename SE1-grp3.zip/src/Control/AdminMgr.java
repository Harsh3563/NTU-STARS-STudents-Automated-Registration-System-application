package Control;

import Entity.Admin;

import java.io.IOException;
import java.util.List;

public class AdminMgr {
    public static void addAdmin(Admin a) throws IOException {
        List<Object> adminList = FileManipMgr.readObjectsFromFile("admin.dat");
        adminList.add(a);
        for(Object admin: adminList)
            System.out.println(((Admin)admin).getNetworkUsername());
        FileManipMgr.writeObjectsToFile(adminList, "admin.dat");
        System.out.println(FileManipMgr.checkIfObjectExists(a));
    }
}
