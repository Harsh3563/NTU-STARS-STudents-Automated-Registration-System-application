package Control;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.PasswordAuthentication;
import java.util.Properties;

public class NotificationMgr
{
    /**
     * NotificationMgr A pingging system that
     * will send emails to specified email locations
     */
    private static final String host_email = "starsse1gr3@gmail.com";
    private static final String host_pwd = "Sample@pass1";

    /**
     * Email function to send emails to users
     * and also reconfirms if the email has been sent or not
     * @param recipient_email The target user to send an email to
     * @param courseID The courseID that user registered
     * @param indexNum Record of the index
     *
     */
    public static void sendEmail(String recipient_email, String courseID, int indexNum) {
        /**
         * Create an object in properties class
         */
        Properties p_obj = new Properties();
        p_obj.put("mail.smtp.host", "smtp.gmail.com");
        p_obj.put("mail.smtp.socketFactory.port", "465");
        p_obj.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        p_obj.put("mail.smtp.auth", "true");
        p_obj.put("mail.smtp.port", "465");
        /**
         *  Start of a new session
         *  and it requires the login information
         *  of a host email to send the emails
         *  to target users
         */
        Session session = Session.getInstance(p_obj,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(host_email, host_pwd);
                    }
                });

        try {
            /**
             * Will create a new message object
             * and from this send the email to the target
             * while also outputting on the terminal the course registered
             * + the index
             */
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(host_email));
            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient_email));
            msg.setSubject("Waitlist notification");
            msg.setText("You have been registered to " + courseID + " and your registered index number is " + indexNum);

            Transport.send(msg);

            System.out.println("An email has been sent to " + recipient_email + "\n");

        } catch (MessagingException e) {
            /**
             * Should an error occur an error message will be shown in the terminal instead
             */
            System.out.println("Error connecting to the internet!");
        }
    }
}
