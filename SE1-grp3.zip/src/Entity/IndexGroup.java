package Entity;

import java.io.Serializable;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class IndexGroup implements Serializable {

    private String courseCode;
    private int indexNumber;
    private int maxLimit;
    private int vacancy;
    private int numStudentsRegistered;
    private int numStudentsWaiting;
    private String[] studentList;
    private String[] studentsWaiting;
    private int numTuts;
    private int numLabs;
    private Lesson[] tutorial;
    private Lesson[] lab;

    /**
     * Constructor to create an index group object
     * @param courseCode Course to which this index number belongs
     * @param indexNumber Unique index number of this index group
     * @param maxLimit max limit of number of students in index group
     * @param numTuts Number of tutorials for the index group
     * @param numLabs Number of labs for the index group
     */
    public IndexGroup(String courseCode, int indexNumber, int maxLimit,int numTuts, int numLabs){
        this.courseCode = courseCode;
        this.indexNumber = indexNumber;
        this.maxLimit = maxLimit;
        this.vacancy = maxLimit;
        this.numStudentsRegistered = 0;
        this.numStudentsWaiting = 0;
        this.studentList = new String[maxLimit];
        this.studentsWaiting = new String[200];
        this.numTuts = numTuts;
        tutorial = new Lesson[this.numTuts];
        setTutorials();
        this.numLabs = numLabs;
        lab = new Lesson[this.numLabs];
        setLabs();
    }

    /**
     * Method to get the predefined Course code
     * @return Course code string is returned
     */
    public String getCourseCode() {
        return this.courseCode;
    }

    /**
     * Method to get the predefined index number code
     * @return Index number value is returned
     */
    public int getIndexNumber() {
        return this.indexNumber;
    }

    /**
     *
     * @param indexNumber unique index number of this index group
     */
    public void setIndexNumber(int indexNumber) {
        this.indexNumber = indexNumber;
    }

    /**
     * Method to get the student list
     * @return String array of students is returned
     */
    public String[] getStudentList() {
        return studentList;
    }

    /**
     * Method to get the list of students waiting
     * @return String array of students waiting is returned
     */
    public String[] getStudentsWaiting(){
        return studentsWaiting;
    }

    /**
     * Method to get the max limit of students
     * @return Max limit
     */
    public int getMaxLimit() {
        return maxLimit;
    }

    /**
     * Method to set the max limit
     * @param maxLimit value to change
     */
    public void setMaxLimit(int maxLimit) {
        this.maxLimit = maxLimit;
    }

    /**
     * Method to check equality of objects
     * @param i Object to be checked with if the object us the same
     * @return boolean Value to show that the object is or is not the same
     */
    public boolean equals(Object i){
        if(i instanceof IndexGroup)
            return (this.courseCode.equals(((IndexGroup)i).getCourseCode()) &&
                    this.indexNumber == ((IndexGroup)i).getIndexNumber());
        return false;
    }

    /**
     * Method to get the vacancy count
     * @return Total count of vacant slots
     */
    public int getVacancy() {
        return vacancy;
    }

    /**
     * Method to set the new vacancy  count
     * @param vacancy Number to change vacancy count to
     */
    public void setVacancy(int vacancy) {
        this.vacancy = vacancy;
    }

    /**
     * Method to get the total students registered
     * @return Total number of students registered
     */
    public int getNumStudentsRegistered() {
        return numStudentsRegistered;
    }

    /**
     * Method to set/update the nubmer of students registered
     * @param numStudentsRegistered New value to change to
     */
    public void setNumStudentsRegistered(int numStudentsRegistered) {
        this.numStudentsRegistered = numStudentsRegistered;
    }

    /**
     * Method to get the total students waiting
     * @return Total number of students waiting
     */
    public int getNumStudentsWaiting() {
        return numStudentsWaiting;
    }

    /**
     * Method to set/update the nubmer of students waiting
     * @param numStudentsWaiting New value to change to
     */
    public void setNumStudentsWaiting(int numStudentsWaiting) {
        this.numStudentsWaiting = numStudentsWaiting;
    }

    /**
     * Method to set/update the number of students registered
     * @param otherStudList new student list to change to
     */
    private void setStudentsRegistered(String[] otherStudList) {
        this.studentList = otherStudList;
    }

    /**
     * Setting function to set all the details regarding tutorials
     */
    public void setTutorials() {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        Scanner sc = new Scanner(System.in);
        LocalTime startTime;
        LocalTime endTime;
        String day, venue;
        WeeklySchedule weeklySchedule;
        System.out.println("Setting of Tutorials");
        for(int i = 0; i < numTuts; i++) {
            System.out.println("For tutorial " + i);
            System.out.print("Enter Start time(hh:mm:ss): ");
            startTime = LocalTime.parse(sc.next(), timeFormatter);
            System.out.print("Enter End Time: ");
            endTime = LocalTime.parse(sc.next(), timeFormatter);
            System.out.print("Enter Day of the week: ");
            day = sc.next();
            sc.nextLine();
            System.out.println("Enter the venue of this lesson.");
            venue = sc.nextLine();
            System.out.println("Choose whether the lesson is for ODD/EVEN/BOTH weeks.");
            weeklySchedule = WeeklySchedule.chooseWeek();
            tutorial[i] = new Lesson(startTime, endTime, day, venue, weeklySchedule, LessonType.TUTORIAL);
        }
    }

    /**
     * Setting function to set all the details regarding labs
     */
    public void setLabs() {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        Scanner sc = new Scanner(System.in);
        LocalTime startTime;
        LocalTime endTime;
        String day, venue;
        WeeklySchedule weeklySchedule;
        System.out.println("Setting of Labs");
        for(int i = 0; i < numLabs; i++) {
            System.out.println("For lab " + i);
            System.out.print("Enter Start time(hh:mm:ss): ");
            startTime = LocalTime.parse(sc.next(), timeFormatter);
            System.out.print("Enter End Time: ");
            endTime = LocalTime.parse(sc.next(), timeFormatter);
            System.out.print("Enter Day of the week: ");
            day = sc.next();
            sc.nextLine();
            System.out.println("Enter the venue of this lesson.");
            venue = sc.nextLine();
            System.out.println("Choose whether the lesson is for ODD/EVEN/BOTH weeks.");
            weeklySchedule = WeeklySchedule.chooseWeek();
            lab[i] = new Lesson(startTime, endTime, day, venue, weeklySchedule, LessonType.LAB);
        }
    }

    /**
     * Adds the student to the waiting list
     * @param matricNumber Matric number of student to be moved to waiting list
     */
    public void addStudentToWaitingList(String matricNumber) {
        this.studentsWaiting[this.numStudentsWaiting] = matricNumber;
        this.numStudentsWaiting++;
    }

    /**
     * Adds student into registered list
     * @param matricNumber
     */
    public void addStudent(String matricNumber){
        this.studentList[this.numStudentsRegistered] = matricNumber;
        this.numStudentsRegistered++;
        this.vacancy--;
    }

    /**
     * function to print every detail about the index group
     */
    public void printIndexDetails(){
        System.out.printf("%-11s %-7s %-7s\n", this.indexNumber, this.vacancy, this.numStudentsWaiting);
    }

    /**
     * Method to get stored lesson list
     * @return Lesson list is returned
     */
    public Lesson[] getLessons() {
        List<Lesson> lessonList = new ArrayList<>(Arrays.asList(tutorial));
        lessonList.addAll(Arrays.asList(lab));
        Lesson[] lessons = new Lesson[lessonList.size()];
        int count = 0;
        for (Lesson l: lessonList){
            lessons[count] = l;
            count++;
        }
        return lessons;
    }

    /**
     * Swap one student with another
     * @param oldMatricNum of student to be removed
     * @param newMatricNum of student to be added
     */
    public void changeStudent(String oldMatricNum, String newMatricNum){
        List<String> studList;
        int count;
        for(int i=0; i<numStudentsRegistered; ++i){
            if(studentList[i].equals(oldMatricNum)){
                studList = new ArrayList<>(Arrays.asList(studentList));
                studList.set(i, newMatricNum);
                count = 0;
                for(String student: studList)
                    studentList[count++] = student;
                break;
            }
        }
    }

    /**
     * To show the changes in matricnumber
     * @param oldMatricNum old matric number of student
     * @param newMatricNum new matric number of student
     */
    public void reflectChangeInMatricNum(String oldMatricNum, String newMatricNum){
        int counter = 0;
        for(String stud: this.studentList){
            if(stud.equals(oldMatricNum)){
                this.studentList[counter] = newMatricNum;
                return;
            }
            counter++;
        }
        counter = 0;
        for(String stud: this.studentsWaiting){
            if(stud.equals(oldMatricNum)){
                this.studentsWaiting[counter] = newMatricNum;
                return;
            }
            counter++;
        }
    }

    /**
     * Will remove a student from the database
     * @param matricNum Find which student to remove
     * @param status status to indicate whether the student is in registered or waiting list
     * @return String Return the matric number of the removed student
     */
    public String removeStudent(String matricNum, int status) {
        int counter;
        String matricNumOfNewStud = "NoWaiting";
        if(status == 1){
            List<String> studList, studList1;
            for(int i=0; i<numStudentsRegistered; ++i){
                if(studentList[i].equals(matricNum)) {
                    studList = new ArrayList<>(Arrays.asList(studentList));
                    studList.remove(i);
                    if (this.numStudentsWaiting != 0) {
                        studList1 = new ArrayList<>(Arrays.asList(studentsWaiting));
                        matricNumOfNewStud = studList1.remove(0);
                        counter = 0;
                        for (String s : studList1)
                            studentsWaiting[counter++] = s;
                        studList.add(i, matricNumOfNewStud);
                        this.numStudentsWaiting--;
                    } else {
                        this.numStudentsRegistered--;
                        this.vacancy++;
                    }
                    counter = 0;
                    for(String s: studList)
                        studentList[counter++] = s;
                    break;
                }
            }
        }
        else if(status == 2){
            List<String> studList;
            for(int i=0; i<numStudentsWaiting; ++i)
                if(studentsWaiting[i].equals(matricNum)) {
                    studList = new ArrayList<>(Arrays.asList(studentsWaiting));
                    studList.remove(i);
                    counter = 0;
                    for(String s: studList)
                        studentsWaiting[counter++] = s;
                    this.numStudentsWaiting--;
                    break;
                }
        }
        return matricNumOfNewStud;
    }

    /**
     * This is to show the changes in Maxlimit
     * @param oldMaxLimit Previous max limit
     * @param maxLimit New max limit to change to
     * @return List String of the changes
     */
    public List<String> reflectChangesInMaxLimit(int oldMaxLimit, int maxLimit) {
        this.maxLimit = maxLimit;
        int count = 0, counter = 0;
        ArrayList<String> newStudList = new ArrayList<>();
        ArrayList<String> studList = new ArrayList<>(Arrays.asList(studentList));
        while(count < (maxLimit - oldMaxLimit)){
            if (this.numStudentsWaiting != 0) {
                ArrayList<String> studList1 = new ArrayList<>(Arrays.asList(studentsWaiting));
                String matricNumOfNewStud = studList1.remove(0);
                counter = 0;
                for (String s : studList1)
                    studentsWaiting[counter++] = s;
                studList.add(this.numStudentsRegistered, matricNumOfNewStud);
                this.numStudentsRegistered++;
                this.numStudentsWaiting--;
                newStudList.add(matricNumOfNewStud);
            }
            else{
                break;
            }
            count++;
        }
        counter = 0;
        this.studentList = new String[this.numStudentsRegistered];
        for(String s: studList)
            studentList[counter++] = s;
        this.vacancy += (maxLimit - oldMaxLimit) - count;
        return newStudList;
    }

    /*public void printEveryDetail(){
        System.out.println("Index Number:" + this.indexNumber);
        System.out.println("Vacancy: " + this.vacancy);
        System.out.println("No. of students registered: " + this.numStudentsRegistered);
        System.out.println("No. of students waiting: " +this.numStudentsWaiting);
        System.out.println("Students registered:");
        for(int i=0; i<numStudentsRegistered; ++i)
            System.out.println(studentList[i]);
        System.out.println("Students waiting: ");
        for(int i=0; i<numStudentsWaiting; ++i)
            System.out.println(studentsWaiting[i]);
        System.out.println("Lessons: ");
        Lesson[] lessons = getLessons();
        for(int i=0; i<lessons.length; ++i){
            lessons[i].displayEveryDetail();
        }
    }*/
}
