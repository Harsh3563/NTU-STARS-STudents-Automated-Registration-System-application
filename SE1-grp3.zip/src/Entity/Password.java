package Entity;

import java.io.Serializable;
public class Password implements  Serializable{

    private String username;
    private String domain;
    private String encryptedPassword;

    /**
     * dummy constructor
     */
    public Password(){}

    /**
     * Password constructor
     * @param user Username
     * @param place Domain of user
     * @param hex Hexed conversion of password
     */
    public Password (String user,String place,String hex){
        this.domain=place;
        this.username=user;
        this.encryptedPassword=hex;
    }

    /**
     * Method to convert encrypted password to string
     * @return Endrcypted password
     */
    @Override
    public String toString() {
        return encryptedPassword;
    }

    /**
     * @param h Object downcasted to the password class and checked
     * with the stored password in the predefined file
     */
    public boolean equals(Object h){
        Password conv = new Password();
        if(h instanceof Password)
            conv = (Password)h;
        return conv.domain.equals(this.domain) && conv.encryptedPassword.equals(this.encryptedPassword) && conv.username.equals(this.username);
    }

    /**
     * Method to get the username
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Method to set the network name
     * @param newNetworkUsername name to changed to
     */
    public void setUsername(String newNetworkUsername) {
        this.username = newNetworkUsername;
    }

    /**
     * Method to get the domain
     * @return domain
     */
    public String getDomain() {
        return domain;
    }


}
