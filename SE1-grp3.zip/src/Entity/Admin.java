package Entity;

import java.io.Serializable;
/**
 * Admin class attributes and functions that only
 * are for admins
 *
 */

public class Admin extends NetworkUser implements Serializable {
    /**
     *constructor for admin class
     * @param networkUsername User name to define
     * @param name Name of admin
     * @param emailID EmailID of admin
     */
    public Admin(String networkUsername, String name, String emailID){
        super(name, networkUsername, emailID);
    }

    /**
     * dummy constructor
     * @param networkUsername network username of admin
     */
    public Admin(String networkUsername){
        super(networkUsername);
    }

    /**
     *equals Method that checks if the object is the same as the
     *stored username
     *@param a object to be checked with
     */
    @Override
    public boolean equals(Object a){
        if(a instanceof Admin)
            return getNetworkUsername().equals(((Admin)a).getNetworkUsername());
        return false;
    }
}
