package Entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Student extends NetworkUser implements Serializable {
    private String matricNumber;
    private String nationality;
    private char gender;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private HashMap<String, Integer> coursesRegistered = new HashMap<>();
    private HashMap<String, Integer> coursesWaiting = new HashMap<>();
    private TimeTable timeTable;
    private int AUsRegistered;

    /**
     * student constructor
     * @param name Name of student
     * @param matricNumber Matirc number of student
     * @param emailID Email ID of the student
     * @param nationality Nationality of the student
     * @param gender Gender of the student
     * @param AUsRegistered Total AUs registered
     * @param networkUsername Network username
     */
    public Student(String name, String matricNumber, String emailID, String nationality, char gender, int AUsRegistered,
            String networkUsername) {
        super(name, networkUsername, emailID);
        this.matricNumber = matricNumber;
        this.nationality = nationality;
        this.gender = gender;
        this.AUsRegistered = AUsRegistered;
        this.startDate = LocalDate.of(2020, 11, 12);
        this.endDate = LocalDate.of(2020, 11, 26);
        this.startTime = LocalTime.of(10, 0, 0);
        this.endTime = LocalTime.of(22, 0, 0);
        this.timeTable = new TimeTable();
    }

    /**
     * dummy constructor
     * @param matricNo matric number of student
     */
    public Student(String matricNo) {
        this.matricNumber = matricNo;
    }

    /**
     * Method to get the matric number
     * @return Matric nubmer
     */
    public String getMatricNumber() {
        return matricNumber;
    }

    /**
     * Method to set the matric number
     * @param matricNumber matric number to be changed to
     */
    public void setMatricNumber(String matricNumber) {
        this.matricNumber = matricNumber;
    }

    /**
     * Method to get the nationality
     * @return nationality
     */
    public String getNationality() {
        return nationality;
    }

    /**
     * Method to set the nationality
     * @param nationality new nationality
     */
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    /**
     * Method to get the gender
     * @return gender
     */
    public char getGender() {
        return gender;
    }

    /**
     * Method to set the gender
     * @param gender New gender to update
     */
    public void setGender(char gender) {
        this.gender = gender;
    }

    /**
     * Method to get the startdate
     * @return Localdate object, startdate
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /**
     * Method to set start date
     * @param startDate To be updated to
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /**
     * Method to get the end date
     * @return Local date object, endDate
     */
    public LocalDate getEndDate() {
        return endDate;
    }

    /**
     * Method to set the end date
     * @param endDate object, end date
     */
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    /**
     * Method to get the starting time
     * @return start time
     */
    public LocalTime getStartTime() {
        return startTime;
    }

    /**
     * Method to set starting time
     * @param startTime object, start time
     */
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    /**
     * Method to get the ending time
     * @return end time
     */
    public LocalTime getEndTime() {
        return endTime;
    }

    /**
     * Method to set ending time
     * @param endTime object, end time
     */
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    /**
     * Method to get total AUs registered
     * @return Total AUs registered
     */
    public int getAUsRegistered() {
        return AUsRegistered;
    }

    /**
     * Method to set the Aus registered
     * @param AUsRegistered Total summation of AUs
     */
    public void setAUsRegistered(int AUsRegistered) {
        this.AUsRegistered = AUsRegistered;
    }

    /**
     * Method to get timetable
     * @return object of Timetable class
     */
    public TimeTable getTimeTable(){
        return timeTable;
    }

    /**
     * Method to get list of all the courses registered + index
     * @return Hashmap of courses registered
     */
    public HashMap<String, Integer> getCoursesRegistered() {
        return coursesRegistered;
    }

    /**
     * Method to get list of all the courses on waiting list + index
     * @return Hashmap of courses waiting
     */
    public HashMap<String, Integer> getCoursesWaiting(){
        return coursesWaiting;
    }

    /**
     * Method will get all the courses into a Hashmap
     * @return Hashmap Object containing all courses is returned
     */
    public HashMap<String, Integer> getCourses() {
        HashMap<String, Integer> courses = new HashMap();
        courses.putAll(coursesRegistered);
        courses.putAll(coursesWaiting);
        return courses;
    }

    /**
     * Method to check equality of 2 student objects
     * @param s Student object that will be compared
     */
    @Override
    public boolean equals(Object s){
        if(s instanceof Student)
            return (this.matricNumber.equals(((Student)s).getMatricNumber()));
        return false;
    }


    /*public void displayEveryDetail(){
        System.out.println("Network Username: " + super.getNetworkUsername());
        System.out.println("Name: " + super.getName());
        System.out.println("Email: " + super.getEmailID());
        System.out.println("Gender: " + this.gender);
        System.out.println("Nationality: " + this.nationality);
        System.out.println("Matric Number: " + this.matricNumber);
        System.out.println("Start Date: " + this.startDate);
        System.out.println("End Date: " + this.endDate);
        System.out.println("Start Time: " + this.startTime);
        System.out.println("End Time: " + this.endTime);
        System.out.println("Number of AUs registered: " + this.AUsRegistered);
        System.out.println("Courses Registered: ");
        System.out.println(coursesRegistered);
        System.out.println("Courses Waiting: ");
        System.out.println(coursesWaiting);
        System.out.println("Time table: ");
        this.timeTable.printTimeTable();
    }*/

    /**
     * Display all information regarding the student
     */
    public void displayDetails() {
        System.out.printf("%-15s %-7s %-15s\n", super.getName(), this.gender, this.nationality);
    }

    /**
     * @param courseCode To register the specific course
     * @param indexNum Specific indexnumber to add it to
     * @param numAUs Adds this value to the current AUs  registered
     */
    public void registerForCourse(String courseCode, int indexNum, int numAUs){
        this.coursesRegistered.put(courseCode, indexNum);
        this.AUsRegistered += numAUs;
    }

    /**
     * Waiting list adding
     * @param courseCode Will be added to waiting list
     * @param indexNum Index of the course to be added to waiting list
     */
    public void addCourseToWaitingList(String courseCode, int indexNum){
        this.coursesWaiting.put(courseCode, indexNum);
    }

    /**
     * Checker to see if course has already been applied
     * @param courseCode To check if specific Coursecode has already been applied
     * @return boolean Value to show if the process is successful
     */
    public boolean checkIfAlreadyApplied(String courseCode){
        Iterator<Map.Entry<String, Integer>> it = coursesRegistered.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Integer> l = it.next();
            if(l.getKey().equals(courseCode))
            {
                System.out.println("You have already registered for this course!");
                return true;
            }
        }
        it = coursesWaiting.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Integer> l = it.next();
            if(l.getKey().equals(courseCode))
            {
                System.out.println("You are already on waiting list for this course!");
                return true;
            }
        }
        return false;
    }

    /**
     * Remove a registered course
     * @param courseCode Course to be removed
     * @param AUs Au count to be changed too
     * @return Integer array
     */
    public Integer[] deregisterFromCourse(String courseCode, int AUs) {
        int status = -1, indexNum = 0;
        boolean flag = true;
        if(coursesRegistered.containsKey(courseCode)){
            indexNum = coursesRegistered.get(courseCode);
            flag = false;
            status = 1;
            coursesRegistered.remove(courseCode);
        }
        else if(coursesWaiting.containsKey(courseCode)){
            indexNum = coursesWaiting.get(courseCode);
            flag = false;
            status = 2;
            coursesWaiting.remove(courseCode);
        }
        if(flag) {
            System.out.println("You have neither registered nor are on waiting list for this course!");
            return new Integer[]{-1, -1};
        }
        this.timeTable.removeLessons(courseCode);
        if(status == 1)
            this.AUsRegistered -= AUs;
        return new Integer[]{status, indexNum};
    }

    /**
     * Will change the status from waiting to registered
     * @param courseCode Course to be changed
     * @param AUs AU count to be changed
     */
    public void changeWaitingToRegistered(String courseCode, int AUs) {
        int indexNum = coursesWaiting.get(courseCode);
        coursesWaiting.remove(courseCode);
        coursesRegistered.put(courseCode, indexNum);
        this.AUsRegistered += AUs;
        this.timeTable.changeWaitingToRegistered(courseCode);
    }

    /**
     * Setting of the course code
     * @param courseCode CourseCode to change to
     * @param newIndexNum Updated index number
     * @param newLessonList Updated lesson list
     */
    public void changeIndex(String courseCode, int newIndexNum, Lesson[] newLessonList){
        this.coursesRegistered.replace(courseCode, newIndexNum);
        this.timeTable.removeLessons(courseCode);
        this.timeTable.addLesson(courseCode, newIndexNum, newLessonList, "REGISTERED");
    }

    /**
     * To show all the changes
     * @param oldCourseCode Old course code value
     * @param newCourseCode New course code value
     */
    public void reflectChangesInCourseCode(String oldCourseCode, String newCourseCode){
        this.timeTable.reflectChangesInCourseCode(oldCourseCode, newCourseCode);
        Iterator<Map.Entry<String, Integer>> it = coursesRegistered.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Integer> l = it.next();
            if(l.getKey().equals(oldCourseCode)){
                String key = l.getKey();
                Integer val = l.getValue();
                coursesRegistered.remove(key);
                key = newCourseCode;
                coursesRegistered.put(key, val);
                return;
            }
        }
        it = coursesWaiting.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Integer> l = it.next();
            if(l.getKey().equals(oldCourseCode)){
                String key = l.getKey();
                Integer val = l.getValue();
                coursesWaiting.remove(key);
                key = newCourseCode;
                coursesWaiting.put(key, val);
                return;
            }
        }
    }

    /**
     * To show the changes in AU
     * @param oldAU Old AU count
     * @param newAU New AU count
     */
    public void reflectChangesInAU(int oldAU, int newAU){
        this.AUsRegistered = this.AUsRegistered - oldAU + newAU;
    }
}
