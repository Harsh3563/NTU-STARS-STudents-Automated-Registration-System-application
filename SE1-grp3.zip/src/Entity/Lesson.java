package Entity;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalTime;
/**
 * Lesson class
 */
public class Lesson implements Serializable {
    private LocalTime startTime;
    private LocalTime endTime;
    private Day day;
    private Duration duration;
    private String venue;
    private WeeklySchedule weeklySchedule;
    private LessonType lessonType;

    /**
     * Lesson class constructor
     * @param startTime Start time of the class
     * @param endTime End time of class
     * @param day The days class will be on
     * @param venue Location of the class
     * @param weeklySchedule Can be odd/even weeks or both
     * @param lessonType Type of lesson
     */
    public Lesson(LocalTime startTime, LocalTime endTime, String day,
                  String venue, WeeklySchedule weeklySchedule, LessonType lessonType){
        this.startTime = startTime;
        this.endTime = endTime;
        this.day = Day.valueOf(day);
        this.duration = Duration.between(endTime, startTime);
        this.venue = venue;
        this.weeklySchedule = weeklySchedule;
        this.lessonType = lessonType;
    }

    /**
     * Sets the time duration by taking the endtime-starttime
     */
    public LocalTime getStartTime() {
        return startTime;
    }

    /**
     * To get the stored starting time
     * @param startTime previously defind
     */
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    /**
     * Method to get the end time
     * @return end time
     */
    public LocalTime getEndTime() {
        return endTime;
    }

    /**
     * Method to set the ending time
     * @param endTime new ending time
     */
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    /**
     * Method to get the Day
     * @return day of the week of lesson
     */
    public Day getDay() {
        return day;
    }

    /**
     * Method to set the day in Lesson class
     * @param day new day to set
     */
    public void setDay(Day day) {
        this.day = day;
    }

    /**
     * Total duration of the lesson
     * @return duration of the lesson
     */
    public Duration getDuration() {
        return duration;
    }

    /**
     * Sets the time duration by taking the endtime-starttime
     * @param duration Total time duration
     */
    public void setDuration(Duration duration) {
        duration = Duration.between(endTime, startTime);
    }

    /**
     * Display method to show all details
     */
    public void displayEveryDetail(){
        System.out.println("Start Time : " + startTime);
        System.out.println("End Time : " + endTime);
        System.out.println("Day : " + day.toString());
        System.out.println("Duration : " + duration);
        System.out.println("Venue : " + venue);
        System.out.println("Weekly Schedule : " + weeklySchedule);
        System.out.println("Lesson Type : " + lessonType);
    }

    /**
     * Method to get the weekly schedule
     * @return weekly schedule
     */
    public WeeklySchedule getWeeklySchedule() {
        return weeklySchedule;
    }

    /**
     * Method to set the weekly schedule
     * @param weeklySchedule new weekly schedule
     */
    public void setWeeklySchedule(WeeklySchedule weeklySchedule) {
        this.weeklySchedule = weeklySchedule;
    }

    /**
     * Method to get the location of the lesson
     * @return location of the lesson
     */
    public String getVenue() {
        return venue;
    }

    /**
     * Method to set the location of the lesson
     * @param venue location of the lesson
     */
    public void setVenue(String venue) {
        this.venue = venue;
    }

    /**
     * Method to get the lesson type
     * @return Lessontype type of lesson (lecture, tut, lab)
     */
    public LessonType getLessonType() {
        return lessonType;
    }

    /**
     * Method to set the lesson type
     * @param lessonType New lesson type to be changed to
     */
    public void setLessonType(LessonType lessonType) {
        this.lessonType = lessonType;
    }
}
