package Entity;

import java.io.Serializable;

public abstract class NetworkUser implements Serializable {
    private String networkUsername;
    private String name;
    private String emailID;

    /**
     * Dummy constructor
     */
    protected NetworkUser(){ }

    /**
     * Parameterized Constructor for NetworkUser
     * @param name name of the user
     * @param networkUsername network username of the user
     * @param emailID email ID of the user
     */
    protected NetworkUser(String name, String networkUsername, String emailID) {
        this.name = name;
        this.networkUsername = networkUsername;
        this.emailID = emailID;
    }

    /**
     * dummy constructor with only network username
     * @param networkUsername network username of user
     */
    protected NetworkUser(String networkUsername) {
        this.networkUsername = networkUsername;
    }

    /**
     * Method to get the network username
     * @return network username
     */
    public String getNetworkUsername() {
        return networkUsername;
    }

    /**
     * Method to set the network username
     * @param networkUsername New network username to change to
     */
    public void setNetworkUsername(String networkUsername) {
        this.networkUsername = networkUsername;
    }

    /**
     * Method to get the name of user
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Method to set the name
     * @param name new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Method to get the EmailID of user
     * @return EmailID is returned
     */
    public String getEmailID() {
        return emailID;
    }

    /**
     * Method to set the emailID
     * @param emailID to changed to
     */
    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    /**
     * abstract method to be overridden in the derived classes
     * @param s Object to be compared with
     * @return boolean value indicating equality
     */
    public abstract boolean equals(Object s);
}
