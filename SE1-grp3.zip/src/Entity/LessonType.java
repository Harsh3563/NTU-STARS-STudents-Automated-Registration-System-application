package Entity;
/**
 * enum class with different lesson types
 */
public enum LessonType {
    LECTURE,
    TUTORIAL,
    LAB
}
